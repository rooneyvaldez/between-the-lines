
import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';

const Home = () => {
  const [quote, setQuote] = useState('');
  const [featuredPosts, setFeaturedPosts] = useState([]);

  useEffect(() => {
    const fetchQuote = async () => {
      const res = await fetch('http://localhost:5000/api/quote-of-the-week');
      const data = await res.json();
      setQuote(data.quote);
    };

    const fetchPosts = async () => {
      const res = await fetch('http://localhost:5000/api/featured-posts');
      const data = await res.json();
      setFeaturedPosts(data.posts);
    };

    fetchQuote();
    fetchPosts();
  }, []);

  return (
    <div className="bg-white dark:bg-gray-950 text-gray-800 dark:text-gray-100">
      <section className="text-center py-20 bg-gradient-to-br from-blue-100 via-white to-pink-100 dark:from-gray-800 dark:to-gray-900">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">Between the Lines</h1>
        <p className="text-xl md:text-2xl italic mb-6">Read. Dream. Repeat.</p>
        <Link to="/stories" className="inline-block bg-blue-600 text-white px-6 py-3 rounded-full text-lg hover:bg-blue-700 transition">Start Reading</Link>
      </section>

      <section className="py-12 px-4 max-w-6xl mx-auto">
        <h2 className="text-3xl font-semibold mb-6">Featured Posts</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {featuredPosts.map(post => (
            <motion.div
              key={post.id}
              className="bg-white dark:bg-gray-800 shadow rounded-xl p-4 hover:shadow-md transition"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5 }}
            >
              <h3 className="text-xl font-bold mb-2">{post.title}</h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">{post.excerpt}</p>
              <Link to={`/post/${post.slug}`} className="text-blue-600 dark:text-blue-400 mt-2 inline-block">Read More →</Link>
            </motion.div>
          ))}
        </div>
      </section>

      <section className="py-16 px-4 bg-gradient-to-r from-purple-100 to-pink-100 dark:from-purple-800 dark:to-pink-900 text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-4">Quote of the Week</h2>
        <blockquote className="italic text-xl max-w-3xl mx-auto">{quote}</blockquote>
        <Link to="/quote" className="mt-4 inline-block text-blue-600 dark:text-blue-400 font-medium">Explore More Quotes</Link>
      </section>
    </div>
  );
};

export default Home;
